package com.example.viplive

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.viplive.data.ChatMessage
import com.example.viplive.data.LiveSession
import com.example.viplive.data.ProductHighlight
import com.example.viplive.data.activeLives
import com.example.viplive.data.initialChat
import com.example.viplive.data.upcomingLives
import com.example.viplive.ui.theme.VIPLiveTheme
import com.example.viplive.ui.theme.VipBlack
import com.example.viplive.ui.theme.VipGold
import com.example.viplive.ui.theme.VipPink
import com.example.viplive.ui.theme.VipSurface
import org.jitsi.meet.sdk.JitsiMeet
import org.jitsi.meet.sdk.JitsiMeetActivity
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions
import org.jitsi.meet.sdk.JitsiMeetView
import java.net.URL

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureJitsiDefaults()

        setContent {
            VIPLiveTheme(darkTheme = true) {
                VIPLiveApp(
                    openJitsiFullScreen = { roomName -> launchJitsiFullScreen(roomName) }
                )
            }
        }
    }

    private fun configureJitsiDefaults() {
        val serverUrl = URL("https://meet.jit.si")
        val defaultOptions = JitsiMeetConferenceOptions.Builder()
            .setServerURL(serverUrl)
            .setFeatureFlag("welcomepage.enabled", false)
            .setFeatureFlag("prejoinpage.enabled", false)
            .setFeatureFlag("invite.enabled", false)
            .build()
        JitsiMeet.setDefaultConferenceOptions(defaultOptions)
    }

    private fun launchJitsiFullScreen(roomName: String) {
        val options = JitsiMeetConferenceOptions.Builder()
            .setRoom(roomName)
            .setAudioMuted(false)
            .setVideoMuted(false)
            .build()
        JitsiMeetActivity.launch(this, options)
    }
}

private enum class Screen { Home, Live }

@Composable
fun VIPLiveApp(openJitsiFullScreen: (String) -> Unit) {
    var selectedLive by remember { mutableStateOf(activeLives.first()) }
    var currentScreen by remember { mutableStateOf(Screen.Home) }

    Surface(modifier = Modifier.fillMaxSize(), color = VipBlack) {
        when (currentScreen) {
            Screen.Home -> HomeScreen(
                active = activeLives,
                upcoming = upcomingLives,
                onEnterRoom = { live ->
                    selectedLive = live
                    currentScreen = Screen.Live
                }
            )
            Screen.Live -> JitsiLiveCommerceScreen(
                live = selectedLive,
                onBack = { currentScreen = Screen.Home },
                openJitsiFullScreen = openJitsiFullScreen
            )
        }
    }
}

@Composable
fun HomeScreen(
    active: List<LiveSession>,
    upcoming: List<LiveSession>,
    onEnterRoom: (LiveSession) -> Unit
) {
    Scaffold(
        containerColor = VipBlack,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { onEnterRoom(active.first()) },
                icon = { Icon(Icons.Default.Videocam, contentDescription = null) },
                text = { Text("Entrar na Sala de Transmissão") },
                containerColor = VipPink,
                contentColor = Color.White
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .statusBarsPadding(),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                HomeHeader()
            }
            item {
                SectionTitle(title = "Lives Ativas", subtitle = "Entre agora, converse e compre em tempo real.")
            }
            items(active) { live ->
                LiveCard(live = live, onEnterRoom = { onEnterRoom(live) })
            }
            item {
                Spacer(modifier = Modifier.height(8.dp))
                SectionTitle(title = "Próximas Lives", subtitle = "Programe-se para os próximos drops VIP.")
            }
            items(upcoming) { live ->
                UpcomingLiveCard(live = live)
            }
            item { Spacer(modifier = Modifier.height(96.dp)) }
        }
    }
}

@Composable
private fun HomeHeader() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        AssistChip(
            onClick = {},
            label = { Text("Live Commerce · Moda") },
            leadingIcon = {
                Box(
                    modifier = Modifier
                        .size(9.dp)
                        .clip(CircleShape)
                        .background(VipPink)
                )
            }
        )
        Text(
            text = "VIP Live",
            style = MaterialTheme.typography.headlineLarge,
            color = Color.White
        )
        Text(
            text = "Venda roupas ao vivo com vídeo, chat e compra contextual no mesmo fluxo.",
            style = MaterialTheme.typography.bodyLarge,
            color = Color(0xFFC8C8D8)
        )
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, color = Color.White)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9A9AAF))
    }
}

@Composable
private fun LiveCard(live: LiveSession, onEnterRoom: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = VipSurface),
        shape = RoundedCornerShape(28.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp)
                .background(
                    Brush.linearGradient(
                        listOf(live.accentColor.copy(alpha = 0.9f), VipSurface, VipBlack)
                    )
                )
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.align(Alignment.TopStart),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LivePill(text = live.startLabel)
                Text(live.title, style = MaterialTheme.typography.headlineMedium, color = Color.White)
                Text("com ${live.hostName}", style = MaterialTheme.typography.bodyLarge, color = Color(0xFFEFEFF8))
                Text("${live.viewers} assistindo", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFD9D9E8))
            }
            Button(
                onClick = onEnterRoom,
                modifier = Modifier.align(Alignment.BottomEnd),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = VipBlack)
            ) {
                Icon(Icons.Default.Videocam, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Entrar")
            }
        }
    }
}

@Composable
private fun UpcomingLiveCard(live: LiveSession) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF11111A)),
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(live.title, color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text("${live.hostName} · ${live.startLabel}", color = Color(0xFF9A9AAF), style = MaterialTheme.typography.bodyMedium)
            }
            TextButton(onClick = {}) { Text("Lembrar", color = VipGold) }
        }
    }
}

@Composable
private fun LivePill(text: String) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(100.dp))
            .background(Color(0xCC000000))
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(Color.Red)
        )
        Spacer(Modifier.width(8.dp))
        Text(text.uppercase(), color = Color.White, style = MaterialTheme.typography.labelMedium)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JitsiLiveCommerceScreen(
    live: LiveSession,
    onBack: () -> Unit,
    openJitsiFullScreen: (String) -> Unit
) {
    val context = LocalContext.current
    var showProductSheet by remember { mutableStateOf(false) }
    var hasPermissions by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        hasPermissions = result[Manifest.permission.CAMERA] == true && result[Manifest.permission.RECORD_AUDIO] == true
    }

    LaunchedEffect(Unit) {
        permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    BackHandler(onBack = onBack)

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        if (hasPermissions) {
            EmbeddedJitsiMeet(roomName = live.roomName)
        } else {
            PermissionPlaceholder()
        }

        LiveOverlay(
            live = live,
            onBack = onBack,
            onShowProduct = { showProductSheet = true },
            onOpenNativeFullScreen = { openJitsiFullScreen(live.roomName) },
            modifier = Modifier.fillMaxSize()
        )
    }

    if (showProductSheet) {
        ModalBottomSheet(
            onDismissRequest = { showProductSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Color(0xFF181824),
            contentColor = Color.White
        ) {
            ProductBottomSheet(product = ProductHighlight(), onBuy = { showProductSheet = false })
        }
    }
}

@Composable
private fun EmbeddedJitsiMeet(roomName: String) {
    var jitsiMeetView: JitsiMeetView? by remember { mutableStateOf(null) }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            JitsiMeetView(context).apply {
                jitsiMeetView = this
                val options = JitsiMeetConferenceOptions.Builder()
                    .setRoom(roomName)
                    .setAudioMuted(false)
                    .setVideoMuted(false)
                    .setFeatureFlag("welcomepage.enabled", false)
                    .setFeatureFlag("prejoinpage.enabled", false)
                    .build()
                join(options)
            }
        }
    )

    DisposableEffect(roomName) {
        onDispose {
            jitsiMeetView?.dispose()
            jitsiMeetView = null
        }
    }
}

@Composable
private fun PermissionPlaceholder() {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Videocam, contentDescription = null, tint = VipPink, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(16.dp))
        Text("Permita câmera e microfone para entrar na live.", color = Color.White, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun LiveOverlay(
    live: LiveSession,
    onBack: () -> Unit,
    onShowProduct: () -> Unit,
    onOpenNativeFullScreen: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.clip(CircleShape).background(Color(0x99000000))) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Voltar", tint = Color.White)
            }
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(live.title, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.White, fontWeight = FontWeight.Bold)
                Text("${live.viewers} clientes na sala", color = Color(0xFFD8D8E8), style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = onOpenNativeFullScreen) {
                Text("SDK Fullscreen", color = VipGold)
            }
        }

        ChatOverlay(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(start = 12.dp, end = 12.dp, bottom = 92.dp)
        )

        ExtendedFloatingActionButton(
            onClick = onShowProduct,
            icon = { Icon(Icons.Default.ShoppingBag, contentDescription = null) },
            text = { Text("Ver Look do Dia") },
            containerColor = VipPink,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(18.dp)
        )
    }
}

@Composable
private fun ChatOverlay(modifier: Modifier = Modifier) {
    val messages = remember { mutableStateListOf<ChatMessage>().apply { addAll(initialChat) } }
    var input by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xAA080810))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Chat da live", color = Color.White, style = MaterialTheme.typography.titleMedium)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            messages.takeLast(4).forEach { msg ->
                Text(
                    text = if (msg.isAdmin) "${msg.author}: ${msg.message}" else "${msg.author}: ${msg.message}",
                    color = if (msg.isAdmin) VipGold else Color.White,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Enviar mensagem") },
                singleLine = true
            )
            IconButton(onClick = {
                if (input.isNotBlank()) {
                    messages.add(ChatMessage("Você", input.trim()))
                    input = ""
                }
            }) {
                Icon(Icons.Default.Send, contentDescription = "Enviar", tint = VipPink)
            }
        }
    }
}

@Composable
private fun ProductBottomSheet(product: ProductHighlight, onBuy: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(22.dp),
        horizontalArrangement = Arrangement.spacedBy(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(id = R.drawable.product_vip_exclusive),
            contentDescription = product.name,
            modifier = Modifier
                .size(132.dp)
                .clip(RoundedCornerShape(28.dp)),
            contentScale = ContentScale.Crop
        )
        Column(
            modifier = Modifier.fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(product.name, style = MaterialTheme.typography.titleLarge, color = Color.White)
            Text(product.description, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFC8C8D8))
            Text(product.price, style = MaterialTheme.typography.headlineMedium, color = VipGold)
            Button(
                onClick = onBuy,
                colors = ButtonDefaults.buttonColors(containerColor = VipPink, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Comprar Agora")
            }
        }
    }
}
