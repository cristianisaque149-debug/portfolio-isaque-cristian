# VIP Live — Protótipo Android Nativo com Kotlin, Jetpack Compose e Jitsi Meet

**VIP Live** é um protótipo funcional de aplicativo Android nativo para **Live Commerce de moda**, desenhado para permitir que um vendedor, chamado no fluxo de exemplo de **Vip Admin**, transmita vídeo e áudio em tempo real enquanto clientes acompanham a live, conversam pelo chat e acessam um destaque de produto diretamente sobre a transmissão. A implementação foi estruturada em **Kotlin** com **Jetpack Compose** para a interface e inclui a dependência do **Jitsi Meet SDK** para a camada de videoconferência.

> A documentação oficial do Jitsi informa que o Android SDK entrega a mesma experiência do app Jitsi Meet em uma forma customizável e embutível dentro de aplicativos Android. Ela também indica que projetos Android devem adicionar o repositório Maven do Jitsi e a dependência `org.jitsi.react:jitsi-meet-sdk` aos arquivos Gradle do projeto.[^1]

## Pré-visualização funcional

A interface também possui uma pré-visualização web interativa, útil para demonstrações rápidas, README do GitHub, validação visual de UI/UX e compartilhamento com stakeholders antes da compilação Android.

| Recurso | Acesso |
|---|---|
| **Link de pré-visualização** | [Abrir protótipo VIP Live](https://8080-ih10wmnhck79fqf1lex0t-1daa3b9e.us1.manus.computer/) |
| **QR Code** | Escaneie a imagem abaixo para abrir a pré-visualização no celular |

![QR Code da pré-visualização VIP Live](https://private-us-east-1.manuscdn.com/sessionFile/vRdngfzXUXtilpdXLHkBFJ/sandbox/1qKN0sXXYbxG2ccNccC7Lg-images_1778886751729_na1fn_L2hvbWUvdWJ1bnR1L3ZpcC1saXZlL2RvY3MvdmlwLWxpdmUtcHJldmlldy1xcg.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvdlJkbmdmelhVWHRpbHBkWExIa0JGSi9zYW5kYm94LzFxS04wc1hYWWJ4RzJjY05jY0M3TGctaW1hZ2VzXzE3Nzg4ODY3NTE3MjlfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwzWnBjQzFzYVhabEwyUnZZM012ZG1sd0xXeHBkbVV0Y0hKbGRtbGxkeTF4Y2cucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=t90n2Vrukdf4TTfXSFXNhTK1R9a5~lwA0zCBhtXI2FgSZUy~YSPZHdYJyq~JO~4xr6mcARZVWHcLVOsngwFxrQJjS5HBAz8eXHpphjGWx~qgG4jGMAdV29OFDoD3~h1OC4ujXuTX1alZQgubXkO3ezWGS97IDnCihjlw6~9zJ5z8lLBegf1VF10zyvSYlpfO6ScjG~-k8j4wXUDjMJnNsteLWk8qdNjQFQ2ectIWnC1sWxyDWpQee3h7RoGZl0-6XzWeXnI3xBtrnSPlVx8J0sPAjRL0RtmUgjv5pYdXRo8N71OXTD8K9ES2YlZKtYEGkPe-7aolFc1dtjzWr65rgw__)

## Funcionalidades implementadas

A Home apresenta um feed limpo e moderno com seções de **Lives Ativas** e **Próximas Lives**, priorizando descoberta rápida e entrada direta na sala de transmissão. O botão destacado **Entrar na Sala de Transmissão** conduz o usuário à experiência de live commerce.

| Tela | Funcionalidade | Status |
|---|---|---|
| **Home** | Feed com lives ativas, próximas lives, contador de audiência e CTA principal | Implementado |
| **Videochamada** | Integração com `JitsiMeetView` embutido em Compose para permitir overlay customizado | Implementado |
| **JitsiMeetActivity** | Método dedicado na `MainActivity` para abrir a sala em modo SDK fullscreen | Implementado |
| **Overlay de venda** | Botão flutuante **Ver Look do Dia** no canto inferior direito | Implementado |
| **Bottom Sheet** | Produto com imagem, nome **Camiseta VIP Exclusive**, preço **R$ 149,90** e CTA **Comprar Agora** | Implementado |
| **Chat simplificado** | Mensagens iniciais e campo para envio de novas mensagens durante a live | Implementado |

## Arquitetura do projeto

A estrutura foi organizada para separar configuração, modelo de dados, tema visual e tela principal. O objetivo é manter o protótipo legível, escalável e fácil de evoluir para integrações reais de catálogo, checkout, autenticação e backoffice do vendedor.

```text
vip-live/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/viplive/
│       │   ├── MainActivity.kt
│       │   ├── data/LiveModels.kt
│       │   └── ui/theme/
│       │       ├── Theme.kt
│       │       └── Type.kt
│       └── res/
│           ├── drawable/product_vip_exclusive.xml
│           └── values/
├── preview/
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── docs/
│   └── vip-live-preview-qr.png
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

## Configuração do Jitsi Meet SDK

O SDK Android do Jitsi exige o repositório Maven mantido pelo projeto Jitsi e a dependência do artefato `org.jitsi.react:jitsi-meet-sdk`. A documentação oficial também observa que o Android 7.0, correspondente ao **API level 24**, ou superior é requerido para uso do SDK.[^1]

```kotlin
// settings.gradle.kts
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven(url = "https://github.com/jitsi/jitsi-maven-repository/raw/master/releases")
        maven(url = "https://www.jitpack.io")
    }
}
```

```kotlin
// app/build.gradle.kts
dependencies {
    implementation("org.jitsi.react:jitsi-meet-sdk:10.1.0") {
        isTransitive = true
    }
}
```

O artefato `jitsi-meet-sdk` está publicado como pacote Android no repositório Maven do Jitsi, e a versão **10.1.0** possui notação Gradle `implementation("org.jitsi.react:jitsi-meet-sdk:10.1.0")` conforme a página pública do Maven Repository.[^2]

## Inicialização da sala Jitsi

A `MainActivity` configura opções padrão do Jitsi no início do aplicativo, usando `https://meet.jit.si` como servidor público de demonstração. A tela de live usa `JitsiMeetView` embutido com `AndroidView`, pois essa abordagem permite desenhar a camada Compose por cima do vídeo, incluindo chat e ações comerciais.

```kotlin
private fun configureJitsiDefaults() {
    val serverUrl = URL("https://meet.jit.si")
    val defaultOptions = JitsiMeetConferenceOptions.Builder()
        .setServerURL(serverUrl)
        .setFeatureFlag("welcomepage.enabled", false)
        .setFeatureFlag("prejoinpage.enabled", false)
        .setFeatureFlag("invite.enabled", false)
        .build()
    JitsiMeet.setDefaultConferenceOptions(defaultOptions)
}
```

A Activity também inclui um método de abertura em tela cheia via `JitsiMeetActivity.launch`, seguindo o padrão documentado pelo Jitsi para entrar em uma conferência por nome de sala.[^1]

```kotlin
private fun launchJitsiFullScreen(roomName: String) {
    val options = JitsiMeetConferenceOptions.Builder()
        .setRoom(roomName)
        .setAudioMuted(false)
        .setVideoMuted(false)
        .build()
    JitsiMeetActivity.launch(this, options)
}
```

## Como executar no Android Studio

Abra a pasta `vip-live` no Android Studio, aguarde o Gradle Sync e execute o módulo `app` em um dispositivo físico ou emulador compatível com câmera e microfone. Para uma experiência mais fiel de videoconferência, recomenda-se testar em dispositivo físico, pois permissões de câmera, microfone e áudio tendem a representar melhor o comportamento real.

| Etapa | Ação |
|---|---|
| **1** | Abrir o projeto no Android Studio como projeto Gradle existente |
| **2** | Confirmar que o `minSdk` está em **24** ou superior |
| **3** | Executar o Gradle Sync para baixar Compose, Material 3 e Jitsi Meet SDK |
| **4** | Rodar o app em um dispositivo físico ou emulador com permissões de câmera e microfone |
| **5** | Entrar na live ativa e validar vídeo, chat, Bottom Sheet e CTA de compra |

## Observações de produto e próximas evoluções

Este protótipo foca a experiência central de live commerce. Em uma versão de produção, o fluxo de compra deve ser integrado a um backend seguro, catálogo real, estoque em tempo real, checkout, autenticação do vendedor e controle de permissões para diferenciar **Vip Admin** de clientes comuns.

| Evolução sugerida | Descrição |
|---|---|
| **Checkout real** | Integrar gateway de pagamento e pedido persistente |
| **Backoffice do Vip Admin** | Criar painel para iniciar lives, selecionar produtos e moderar chat |
| **Catálogo dinâmico** | Buscar looks e preços de API própria ou plataforma de e-commerce |
| **Chat persistente** | Substituir lista local por WebSocket, Firebase ou backend próprio |
| **Analytics de conversão** | Medir espectadores, cliques em produto, carrinhos e vendas por live |

## Referências

[^1]: [Jitsi Meet Handbook — Android SDK](https://jitsi.github.io/handbook/docs/dev-guide/dev-guide-android-sdk/)
[^2]: [MvnRepository — org.jitsi.react:jitsi-meet-sdk:10.1.0](https://mvnrepository.com/artifact/org.jitsi.react/jitsi-meet-sdk/10.1.0)
[^3]: [GitHub — jitsi/jitsi-meet-sdk-samples](https://github.com/jitsi/jitsi-meet-sdk-samples)
