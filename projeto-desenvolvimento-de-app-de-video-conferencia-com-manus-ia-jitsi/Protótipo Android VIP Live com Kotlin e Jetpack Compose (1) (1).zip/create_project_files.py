from pathlib import Path

root = Path('/home/ubuntu/vip-live')
files = {}

files['settings.gradle.kts'] = '''pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven(url = "https://github.com/jitsi/jitsi-maven-repository/raw/master/releases")
        maven(url = "https://www.jitpack.io")
    }
}

rootProject.name = "VIP Live"
include(":app")
'''

files['build.gradle.kts'] = '''plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}
'''

files['app/build.gradle.kts'] = '''plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.viplive"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.viplive"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3:1.3.1")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("org.jitsi.react:jitsi-meet-sdk:10.1.0") {
        isTransitive = true
    }

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
}
'''

files['app/proguard-rules.pro'] = '''# Regras básicas para o SDK do Jitsi Meet e React Native.
-keep class org.jitsi.** { *; }
-keep class com.facebook.react.** { *; }
-keep class com.facebook.hermes.** { *; }
-keep class com.swmansion.** { *; }
-keep class org.webrtc.** { *; }
-dontwarn org.jitsi.**
-dontwarn com.facebook.react.**
-dontwarn com.facebook.hermes.**
-dontwarn org.webrtc.**
'''

files['app/src/main/AndroidManifest.xml'] = '''<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.BLUETOOTH" />
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />

    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="VIP Live"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.VIPLive">

        <activity
            android:name=".MainActivity"
            android:configChanges="keyboard|keyboardHidden|orientation|screenLayout|screenSize|smallestScreenSize|uiMode"
            android:exported="true"
            android:launchMode="singleTask"
            android:screenOrientation="portrait">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
'''

files['app/src/main/res/values/colors.xml'] = '''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="vip_black">#0B0B12</color>
    <color name="vip_pink">#FF2D75</color>
    <color name="vip_gold">#F5C451</color>
</resources>
'''

files['app/src/main/res/values/strings.xml'] = '''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">VIP Live</string>
</resources>
'''

files['app/src/main/res/values/styles.xml'] = '''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.VIPLive" parent="android:style/Theme.Material.Light.NoActionBar">
        <item name="android:windowNoTitle">true</item>
        <item name="android:windowActionBar">false</item>
        <item name="android:windowLightStatusBar">false</item>
        <item name="android:statusBarColor">@color/vip_black</item>
        <item name="android:navigationBarColor">@color/vip_black</item>
    </style>
</resources>
'''

files['app/src/main/res/drawable/product_vip_exclusive.xml'] = '''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="220dp"
    android:height="220dp"
    android:viewportWidth="220"
    android:viewportHeight="220">
    <path android:fillColor="#FFF5F8" android:pathData="M0,0h220v220h-220z"/>
    <path android:fillColor="#FF2D75" android:pathData="M66,54 L92,42 C100,52 120,52 128,42 L154,54 L181,86 L158,107 L146,91 L146,178 L74,178 L74,91 L62,107 L39,86 Z"/>
    <path android:fillColor="#0B0B12" android:pathData="M90,65 Q110,80 130,65 L130,78 Q110,94 90,78 Z"/>
    <path android:fillColor="#F5C451" android:pathData="M91,116 h58 v12 h-58z M99,139 h42 v9 h-42z"/>
</vector>
'''

# Minimal launcher foreground/background resources.
files['app/src/main/res/drawable/ic_launcher_foreground.xml'] = '''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
    <path android:fillColor="#0B0B12" android:pathData="M0,0h108v108h-108z"/>
    <path android:fillColor="#FF2D75" android:pathData="M23,25h62v58h-62z"/>
    <path android:fillColor="#F5C451" android:pathData="M34,39h40v9h-40zM34,58h29v8h-29z"/>
</vector>
'''
files['app/src/main/res/drawable/ic_launcher_background.xml'] = '''<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <solid android:color="#0B0B12" />
</shape>
'''
files['app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml'] = '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
'''
files['app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml'] = files['app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml']

files['app/src/main/java/com/example/viplive/data/LiveModels.kt'] = '''package com.example.viplive.data

import androidx.compose.ui.graphics.Color

data class LiveSession(
    val id: String,
    val title: String,
    val hostName: String,
    val startLabel: String,
    val viewers: Int,
    val roomName: String,
    val isActive: Boolean,
    val accentColor: Color
)

data class ProductHighlight(
    val name: String = "Camiseta VIP Exclusive",
    val price: String = "R$ 149,90",
    val description: String = "Drop limitado da live, com tecido premium e modelagem oversized."
)

data class ChatMessage(
    val author: String,
    val message: String,
    val isAdmin: Boolean = false
)

val activeLives = listOf(
    LiveSession(
        id = "vip-drop-01",
        title = "Drop VIP: Streetwear de Verão",
        hostName = "Vip Admin",
        startLabel = "Ao vivo agora",
        viewers = 248,
        roomName = "VIPLive-Drop-Streetwear",
        isActive = true,
        accentColor = Color(0xFFFF2D75)
    ),
    LiveSession(
        id = "vip-jeans-02",
        title = "Jeans Premium com desconto relâmpago",
        hostName = "Camila Store",
        startLabel = "Ao vivo agora",
        viewers = 126,
        roomName = "VIPLive-Jeans-Premium",
        isActive = true,
        accentColor = Color(0xFF7C4DFF)
    )
)

val upcomingLives = listOf(
    LiveSession(
        id = "vip-night-03",
        title = "Looks para a noite",
        hostName = "Vip Admin",
        startLabel = "Hoje, 20:00",
        viewers = 0,
        roomName = "VIPLive-Looks-Noite",
        isActive = false,
        accentColor = Color(0xFFF5C451)
    ),
    LiveSession(
        id = "vip-outlet-04",
        title = "Outlet VIP: peças selecionadas",
        hostName = "Equipe VIP",
        startLabel = "Amanhã, 19:30",
        viewers = 0,
        roomName = "VIPLive-Outlet",
        isActive = false,
        accentColor = Color(0xFF00C2A8)
    )
)

val initialChat = listOf(
    ChatMessage("Vip Admin", "Boa noite, VIPs! O cupom da live já está ativo.", isAdmin = true),
    ChatMessage("Ana", "Essa camiseta tem tamanho P?"),
    ChatMessage("Bruno", "Quero ver a peça no corpo!"),
    ChatMessage("Vip Admin", "Sim, temos do PP ao GG. Vou mostrar os detalhes agora.", isAdmin = true)
)
'''

files['app/src/main/java/com/example/viplive/ui/theme/Theme.kt'] = '''package com.example.viplive.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val VipBlack = Color(0xFF0B0B12)
val VipSurface = Color(0xFF151521)
val VipSurfaceLight = Color(0xFFF8F7FB)
val VipPink = Color(0xFFFF2D75)
val VipGold = Color(0xFFF5C451)
val VipTextMuted = Color(0xFF9A9AAF)

private val DarkColors = darkColorScheme(
    primary = VipPink,
    secondary = VipGold,
    background = VipBlack,
    surface = VipSurface,
    onPrimary = Color.White,
    onSecondary = VipBlack,
    onBackground = Color.White,
    onSurface = Color.White
)

private val LightColors = lightColorScheme(
    primary = VipPink,
    secondary = VipGold,
    background = VipSurfaceLight,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = VipBlack,
    onBackground = VipBlack,
    onSurface = VipBlack
)

@Composable
fun VIPLiveTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = Typography,
        content = content
    )
}
'''

files['app/src/main/java/com/example/viplive/ui/theme/Type.kt'] = '''package com.example.viplive.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Typography = Typography().copy(
    headlineLarge = Typography().headlineLarge.copy(fontWeight = FontWeight.ExtraBold, fontSize = 32.sp),
    headlineMedium = Typography().headlineMedium.copy(fontWeight = FontWeight.Bold, fontSize = 24.sp),
    titleLarge = Typography().titleLarge.copy(fontWeight = FontWeight.Bold, fontSize = 20.sp),
    titleMedium = Typography().titleMedium.copy(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyLarge = Typography().bodyLarge.copy(fontSize = 16.sp),
    bodyMedium = Typography().bodyMedium.copy(fontSize = 14.sp)
)
'''

files['app/src/main/java/com/example/viplive/MainActivity.kt'] = '''package com.example.viplive

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.viplive.data.ChatMessage
import com.example.viplive.data.LiveSession
import com.example.viplive.data.ProductHighlight
import com.example.viplive.data.activeLives
import com.example.viplive.data.initialChat
import com.example.viplive.data.upcomingLives
import com.example.viplive.ui.theme.VIPLiveTheme
import com.example.viplive.ui.theme.VipBlack
import com.example.viplive.ui.theme.VipGold
import com.example.viplive.ui.theme.VipPink
import com.example.viplive.ui.theme.VipSurface
import org.jitsi.meet.sdk.JitsiMeet
import org.jitsi.meet.sdk.JitsiMeetActivity
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions
import org.jitsi.meet.sdk.JitsiMeetView
import java.net.URL

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureJitsiDefaults()

        setContent {
            VIPLiveTheme(darkTheme = true) {
                VIPLiveApp(
                    openJitsiFullScreen = { roomName -> launchJitsiFullScreen(roomName) }
                )
            }
        }
    }

    private fun configureJitsiDefaults() {
        val serverUrl = URL("https://meet.jit.si")
        val defaultOptions = JitsiMeetConferenceOptions.Builder()
            .setServerURL(serverUrl)
            .setFeatureFlag("welcomepage.enabled", false)
            .setFeatureFlag("prejoinpage.enabled", false)
            .setFeatureFlag("invite.enabled", false)
            .build()
        JitsiMeet.setDefaultConferenceOptions(defaultOptions)
    }

    private fun launchJitsiFullScreen(roomName: String) {
        val options = JitsiMeetConferenceOptions.Builder()
            .setRoom(roomName)
            .setAudioMuted(false)
            .setVideoMuted(false)
            .build()
        JitsiMeetActivity.launch(this, options)
    }
}

private enum class Screen { Home, Live }

@Composable
fun VIPLiveApp(openJitsiFullScreen: (String) -> Unit) {
    var selectedLive by remember { mutableStateOf(activeLives.first()) }
    var currentScreen by remember { mutableStateOf(Screen.Home) }

    Surface(modifier = Modifier.fillMaxSize(), color = VipBlack) {
        when (currentScreen) {
            Screen.Home -> HomeScreen(
                active = activeLives,
                upcoming = upcomingLives,
                onEnterRoom = { live ->
                    selectedLive = live
                    currentScreen = Screen.Live
                }
            )
            Screen.Live -> JitsiLiveCommerceScreen(
                live = selectedLive,
                onBack = { currentScreen = Screen.Home },
                openJitsiFullScreen = openJitsiFullScreen
            )
        }
    }
}

@Composable
fun HomeScreen(
    active: List<LiveSession>,
    upcoming: List<LiveSession>,
    onEnterRoom: (LiveSession) -> Unit
) {
    Scaffold(
        containerColor = VipBlack,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { onEnterRoom(active.first()) },
                icon = { Icon(Icons.Default.Videocam, contentDescription = null) },
                text = { Text("Entrar na Sala de Transmissão") },
                containerColor = VipPink,
                contentColor = Color.White
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .statusBarsPadding(),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                HomeHeader()
            }
            item {
                SectionTitle(title = "Lives Ativas", subtitle = "Entre agora, converse e compre em tempo real.")
            }
            items(active) { live ->
                LiveCard(live = live, onEnterRoom = { onEnterRoom(live) })
            }
            item {
                Spacer(modifier = Modifier.height(8.dp))
                SectionTitle(title = "Próximas Lives", subtitle = "Programe-se para os próximos drops VIP.")
            }
            items(upcoming) { live ->
                UpcomingLiveCard(live = live)
            }
            item { Spacer(modifier = Modifier.height(96.dp)) }
        }
    }
}

@Composable
private fun HomeHeader() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        AssistChip(
            onClick = {},
            label = { Text("Live Commerce · Moda") },
            leadingIcon = {
                Box(
                    modifier = Modifier
                        .size(9.dp)
                        .clip(CircleShape)
                        .background(VipPink)
                )
            }
        )
        Text(
            text = "VIP Live",
            style = MaterialTheme.typography.headlineLarge,
            color = Color.White
        )
        Text(
            text = "Venda roupas ao vivo com vídeo, chat e compra contextual no mesmo fluxo.",
            style = MaterialTheme.typography.bodyLarge,
            color = Color(0xFFC8C8D8)
        )
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, color = Color.White)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF9A9AAF))
    }
}

@Composable
private fun LiveCard(live: LiveSession, onEnterRoom: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = VipSurface),
        shape = RoundedCornerShape(28.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp)
                .background(
                    Brush.linearGradient(
                        listOf(live.accentColor.copy(alpha = 0.9f), VipSurface, VipBlack)
                    )
                )
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.align(Alignment.TopStart),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LivePill(text = live.startLabel)
                Text(live.title, style = MaterialTheme.typography.headlineMedium, color = Color.White)
                Text("com ${live.hostName}", style = MaterialTheme.typography.bodyLarge, color = Color(0xFFEFEFF8))
                Text("${live.viewers} assistindo", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFD9D9E8))
            }
            Button(
                onClick = onEnterRoom,
                modifier = Modifier.align(Alignment.BottomEnd),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = VipBlack)
            ) {
                Icon(Icons.Default.Videocam, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Entrar")
            }
        }
    }
}

@Composable
private fun UpcomingLiveCard(live: LiveSession) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF11111A)),
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(live.title, color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text("${live.hostName} · ${live.startLabel}", color = Color(0xFF9A9AAF), style = MaterialTheme.typography.bodyMedium)
            }
            TextButton(onClick = {}) { Text("Lembrar", color = VipGold) }
        }
    }
}

@Composable
private fun LivePill(text: String) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(100.dp))
            .background(Color(0xCC000000))
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(Color.Red)
        )
        Spacer(Modifier.width(8.dp))
        Text(text.uppercase(), color = Color.White, style = MaterialTheme.typography.labelMedium)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JitsiLiveCommerceScreen(
    live: LiveSession,
    onBack: () -> Unit,
    openJitsiFullScreen: (String) -> Unit
) {
    val context = LocalContext.current
    var showProductSheet by remember { mutableStateOf(false) }
    var hasPermissions by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        hasPermissions = result[Manifest.permission.CAMERA] == true && result[Manifest.permission.RECORD_AUDIO] == true
    }

    LaunchedEffect(Unit) {
        permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    BackHandler(onBack = onBack)

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        if (hasPermissions) {
            EmbeddedJitsiMeet(roomName = live.roomName)
        } else {
            PermissionPlaceholder()
        }

        LiveOverlay(
            live = live,
            onBack = onBack,
            onShowProduct = { showProductSheet = true },
            onOpenNativeFullScreen = { openJitsiFullScreen(live.roomName) },
            modifier = Modifier.fillMaxSize()
        )
    }

    if (showProductSheet) {
        ModalBottomSheet(
            onDismissRequest = { showProductSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Color(0xFF181824),
            contentColor = Color.White
        ) {
            ProductBottomSheet(product = ProductHighlight(), onBuy = { showProductSheet = false })
        }
    }
}

@Composable
private fun EmbeddedJitsiMeet(roomName: String) {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            JitsiMeetView(context).apply {
                val options = JitsiMeetConferenceOptions.Builder()
                    .setRoom(roomName)
                    .setAudioMuted(false)
                    .setVideoMuted(false)
                    .setFeatureFlag("welcomepage.enabled", false)
                    .setFeatureFlag("prejoinpage.enabled", false)
                    .build()
                join(options)
            }
        },
        update = { view ->
            val options = JitsiMeetConferenceOptions.Builder()
                .setRoom(roomName)
                .build()
            view.join(options)
        }
    )
    DisposableEffect(roomName) {
        onDispose {
            // O JitsiMeetView encerra a conferência quando a view é destruída.
        }
    }
}

@Composable
private fun PermissionPlaceholder() {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Videocam, contentDescription = null, tint = VipPink, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(16.dp))
        Text("Permita câmera e microfone para entrar na live.", color = Color.White, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun LiveOverlay(
    live: LiveSession,
    onBack: () -> Unit,
    onShowProduct: () -> Unit,
    onOpenNativeFullScreen: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier) {
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.clip(CircleShape).background(Color(0x99000000))) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Voltar", tint = Color.White)
            }
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(live.title, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.White, fontWeight = FontWeight.Bold)
                Text("${live.viewers} clientes na sala", color = Color(0xFFD8D8E8), style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = onOpenNativeFullScreen) {
                Text("SDK Fullscreen", color = VipGold)
            }
        }

        ChatOverlay(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(start = 12.dp, end = 12.dp, bottom = 92.dp)
        )

        ExtendedFloatingActionButton(
            onClick = onShowProduct,
            icon = { Icon(Icons.Default.ShoppingBag, contentDescription = null) },
            text = { Text("Ver Look do Dia") },
            containerColor = VipPink,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(18.dp)
        )
    }
}

@Composable
private fun ChatOverlay(modifier: Modifier = Modifier) {
    val messages = remember { mutableStateListOf<ChatMessage>().apply { addAll(initialChat) } }
    var input by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xAA080810))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Chat da live", color = Color.White, style = MaterialTheme.typography.titleMedium)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            messages.takeLast(4).forEach { msg ->
                Text(
                    text = if (msg.isAdmin) "${msg.author}: ${msg.message}" else "${msg.author}: ${msg.message}",
                    color = if (msg.isAdmin) VipGold else Color.White,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Enviar mensagem") },
                singleLine = true
            )
            IconButton(onClick = {
                if (input.isNotBlank()) {
                    messages.add(ChatMessage("Você", input.trim()))
                    input = ""
                }
            }) {
                Icon(Icons.Default.Send, contentDescription = "Enviar", tint = VipPink)
            }
        }
    }
}

@Composable
private fun ProductBottomSheet(product: ProductHighlight, onBuy: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(22.dp),
        horizontalArrangement = Arrangement.spacedBy(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(id = R.drawable.product_vip_exclusive),
            contentDescription = product.name,
            modifier = Modifier
                .size(132.dp)
                .clip(RoundedCornerShape(28.dp)),
            contentScale = ContentScale.Crop
        )
        Column(
            modifier = Modifier.fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(product.name, style = MaterialTheme.typography.titleLarge, color = Color.White)
            Text(product.description, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFC8C8D8))
            Text(product.price, style = MaterialTheme.typography.headlineMedium, color = VipGold)
            Button(
                onClick = onBuy,
                colors = ButtonDefaults.buttonColors(containerColor = VipPink, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Comprar Agora")
            }
        }
    }
}
'''

files['preview/index.html'] = '''<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>VIP Live — Pré-visualização</title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <main class="phone" aria-label="Pré-visualização do app VIP Live">
    <section id="home" class="screen active">
      <header class="hero">
        <span class="eyebrow"><span></span> Live Commerce · Moda</span>
        <h1>VIP Live</h1>
        <p>Venda roupas ao vivo com vídeo, chat e compra contextual no mesmo fluxo.</p>
      </header>

      <section class="section-title">
        <h2>Lives Ativas</h2>
        <p>Entre agora, converse e compre em tempo real.</p>
      </section>

      <article class="live-card pink">
        <div class="pill"><span></span> AO VIVO AGORA</div>
        <h3>Drop VIP: Streetwear de Verão</h3>
        <p>com Vip Admin</p>
        <small>248 assistindo</small>
        <button id="enterLive">Entrar</button>
      </article>

      <article class="live-card purple">
        <div class="pill"><span></span> AO VIVO AGORA</div>
        <h3>Jeans Premium com desconto relâmpago</h3>
        <p>com Camila Store</p>
        <small>126 assistindo</small>
      </article>

      <section class="section-title upcoming-title">
        <h2>Próximas Lives</h2>
        <p>Programe-se para os próximos drops VIP.</p>
      </section>

      <article class="upcoming"><div><strong>Looks para a noite</strong><span>Vip Admin · Hoje, 20:00</span></div><button>Lembrar</button></article>
      <article class="upcoming"><div><strong>Outlet VIP</strong><span>Equipe VIP · Amanhã, 19:30</span></div><button>Lembrar</button></article>

      <button class="primary-fab" id="enterLiveFab">Entrar na Sala de Transmissão</button>
    </section>

    <section id="live" class="screen live-screen">
      <div class="video-bg">
        <div class="avatar seller">VIP</div>
        <div class="video-grid">
          <div></div><div></div><div></div><div></div>
        </div>
      </div>
      <div class="topbar">
        <button id="backHome" class="icon-btn">←</button>
        <div><strong>Drop VIP: Streetwear de Verão</strong><span>248 clientes na sala</span></div>
        <button class="sdk-btn">SDK</button>
      </div>
      <aside class="chat">
        <h4>Chat da live</h4>
        <p><b>Vip Admin:</b> Boa noite, VIPs! Cupom ativo.</p>
        <p><b>Ana:</b> Essa camiseta tem tamanho P?</p>
        <p><b>Bruno:</b> Quero ver a peça no corpo!</p>
        <div class="chat-input"><input id="chatInput" placeholder="Enviar mensagem" /><button id="sendChat">➤</button></div>
      </aside>
      <button class="look-btn" id="openSheet">Ver Look do Dia</button>
      <div class="sheet" id="sheet" aria-hidden="true">
        <div class="handle"></div>
        <div class="product-img"><span>VIP</span></div>
        <div class="product-copy">
          <h3>Camiseta VIP Exclusive</h3>
          <p>Drop limitado da live, tecido premium e modelagem oversized.</p>
          <strong>R$ 149,90</strong>
          <button id="buyNow">Comprar Agora</button>
        </div>
      </div>
    </section>
  </main>
  <script src="script.js"></script>
</body>
</html>
'''

files['preview/styles.css'] = '''* { box-sizing: border-box; }
:root { --black:#0b0b12; --surface:#151521; --pink:#ff2d75; --gold:#f5c451; --muted:#aaaabc; }
body { margin:0; min-height:100vh; display:grid; place-items:center; background:radial-gradient(circle at 20% 10%, #3b1230, #0b0b12 45%, #050508); font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; color:#fff; }
.phone { width:min(420px, 100vw); height:min(880px, 100vh); background:var(--black); border:10px solid #191923; border-radius:42px; overflow:hidden; position:relative; box-shadow:0 30px 90px #000b; }
.screen { position:absolute; inset:0; padding:24px; overflow:auto; opacity:0; transform:translateX(25px); pointer-events:none; transition:.35s ease; }
.screen.active { opacity:1; transform:none; pointer-events:auto; }
.hero { padding-top:18px; }
.eyebrow { display:inline-flex; align-items:center; gap:8px; color:#fff; background:#20202c; border:1px solid #303042; border-radius:999px; padding:8px 12px; font-size:13px; }
.eyebrow span, .pill span { width:8px; height:8px; border-radius:50%; background:var(--pink); display:inline-block; }
h1 { font-size:48px; letter-spacing:-2px; margin:18px 0 6px; }
p { color:#cacadc; line-height:1.45; }
.section-title { margin:26px 0 12px; }
.section-title h2 { margin:0; }
.section-title p { margin:4px 0 0; color:var(--muted); font-size:14px; }
.live-card { position:relative; min-height:205px; border-radius:30px; padding:20px; margin:14px 0; overflow:hidden; background:linear-gradient(135deg, var(--pink), var(--surface) 55%, #050508); }
.live-card.purple { background:linear-gradient(135deg, #7c4dff, var(--surface) 55%, #050508); }
.pill { display:inline-flex; gap:8px; align-items:center; border-radius:999px; background:#000a; padding:8px 11px; font-size:12px; font-weight:800; }
.live-card h3 { margin:18px 0 6px; font-size:25px; line-height:1.05; max-width:280px; }
.live-card p, .live-card small { margin:0; color:#eee; }
.live-card button { position:absolute; right:18px; bottom:18px; border:0; border-radius:999px; padding:12px 22px; font-weight:800; }
.upcoming { display:flex; align-items:center; justify-content:space-between; gap:16px; background:#11111a; border-radius:22px; padding:17px; margin:12px 0; }
.upcoming span { display:block; color:var(--muted); margin-top:4px; font-size:13px; }
.upcoming button, .sdk-btn { background:transparent; color:var(--gold); border:0; font-weight:800; }
.primary-fab { position:sticky; bottom:12px; width:100%; border:0; border-radius:999px; background:var(--pink); color:white; padding:17px; font-size:15px; font-weight:900; box-shadow:0 16px 32px #ff2d7555; }
.live-screen { padding:0; overflow:hidden; background:#000; }
.video-bg { position:absolute; inset:0; background:linear-gradient(160deg, #161631, #2b1024 48%, #040408); display:grid; place-items:center; }
.avatar { width:150px; height:150px; border-radius:50%; display:grid; place-items:center; background:linear-gradient(135deg,var(--pink),var(--gold)); color:#08080d; font-size:36px; font-weight:1000; box-shadow:0 0 80px #ff2d7580; }
.video-grid { position:absolute; inset:0; display:grid; grid-template-columns:1fr 1fr; opacity:.16; }
.video-grid div { border:1px solid #fff2; }
.topbar { position:absolute; top:0; left:0; right:0; display:flex; align-items:center; gap:12px; padding:18px 14px; background:linear-gradient(#0009, transparent); }
.topbar div { flex:1; min-width:0; }
.topbar strong, .topbar span { display:block; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.topbar span { color:#d7d7e5; font-size:13px; margin-top:3px; }
.icon-btn { width:42px; height:42px; border-radius:50%; border:0; color:#fff; background:#0008; font-size:22px; }
.chat { position:absolute; left:12px; right:12px; bottom:96px; border-radius:24px; background:#080810bb; padding:14px; backdrop-filter:blur(12px); }
.chat h4 { margin:0 0 8px; }
.chat p { margin:6px 0; font-size:14px; color:#fff; }
.chat p:first-of-type b { color:var(--gold); }
.chat-input { display:flex; gap:8px; margin-top:10px; }
.chat-input input { flex:1; border:1px solid #ffffff20; background:#ffffff10; border-radius:16px; padding:12px; color:#fff; outline:0; }
.chat-input button { border:0; border-radius:14px; width:46px; background:var(--pink); color:#fff; }
.look-btn { position:absolute; right:16px; bottom:24px; border:0; border-radius:999px; background:var(--pink); color:#fff; padding:16px 18px; font-weight:900; box-shadow:0 16px 34px #ff2d7570; }
.sheet { position:absolute; left:0; right:0; bottom:0; display:flex; gap:16px; align-items:center; background:#181824; border-radius:28px 28px 0 0; padding:22px; transform:translateY(110%); transition:.32s ease; box-shadow:0 -18px 50px #0009; }
.sheet.open { transform:translateY(0); }
.handle { position:absolute; top:9px; left:50%; transform:translateX(-50%); width:46px; height:5px; border-radius:999px; background:#ffffff30; }
.product-img { flex:0 0 122px; height:122px; border-radius:26px; background:linear-gradient(135deg,#fff5f8,#ffd0de); display:grid; place-items:center; }
.product-img span { width:74px; height:74px; display:grid; place-items:center; border-radius:22px; background:var(--pink); color:#fff; font-weight:1000; }
.product-copy h3 { margin:0 0 6px; }
.product-copy p { margin:0 0 8px; color:#c9c9d7; font-size:13px; }
.product-copy strong { color:var(--gold); font-size:24px; display:block; margin-bottom:10px; }
.product-copy button { border:0; border-radius:16px; background:var(--pink); color:#fff; padding:12px 16px; font-weight:900; width:100%; }
@media (max-width:440px) { .phone { border:0; border-radius:0; width:100vw; height:100vh; } }
'''

files['preview/script.js'] = '''const home = document.getElementById('home');
const live = document.getElementById('live');
const sheet = document.getElementById('sheet');
const chatInput = document.getElementById('chatInput');
const chat = document.querySelector('.chat');

function showLive() { home.classList.remove('active'); live.classList.add('active'); }
function showHome() { live.classList.remove('active'); home.classList.add('active'); sheet.classList.remove('open'); }

document.getElementById('enterLive').addEventListener('click', showLive);
document.getElementById('enterLiveFab').addEventListener('click', showLive);
document.getElementById('backHome').addEventListener('click', showHome);
document.getElementById('openSheet').addEventListener('click', () => sheet.classList.toggle('open'));
document.getElementById('buyNow').addEventListener('click', () => {
  sheet.classList.remove('open');
  alert('Protótipo: fluxo de compra iniciado para Camiseta VIP Exclusive.');
});
document.getElementById('sendChat').addEventListener('click', () => {
  const value = chatInput.value.trim();
  if (!value) return;
  const p = document.createElement('p');
  p.innerHTML = `<b>Você:</b> ${value}`;
  chat.insertBefore(p, document.querySelector('.chat-input'));
  chatInput.value = '';
});
chatInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') document.getElementById('sendChat').click();
});
'''

for rel, content in files.items():
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8')

print(f'Arquivos gerados em {root}')
