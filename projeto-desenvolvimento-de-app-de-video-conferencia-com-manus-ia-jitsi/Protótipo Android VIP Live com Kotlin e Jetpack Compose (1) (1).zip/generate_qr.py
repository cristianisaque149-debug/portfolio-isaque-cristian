from pathlib import Path
import qrcode

preview_url = 'https://8080-ih10wmnhck79fqf1lex0t-1daa3b9e.us1.manus.computer/'
out = Path('/home/ubuntu/vip-live/docs/vip-live-preview-qr.png')
qr = qrcode.QRCode(
    version=None,
    error_correction=qrcode.constants.ERROR_CORRECT_H,
    box_size=12,
    border=4,
)
qr.add_data(preview_url)
qr.make(fit=True)
img = qr.make_image(fill_color='#0B0B12', back_color='white').convert('RGB')
out.parent.mkdir(parents=True, exist_ok=True)
img.save(out)
print(out)
